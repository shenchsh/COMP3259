module TypeCheck where

import Declare
import Interp
import Parser
import Prelude hiding (LT, GT, EQ)

data Type
  = TInt
  | TBool
  deriving (Eq,Show)

type TEnv = [(String,Type)]


-- | Question 4
--
-- >>> tunary Neg TInt
-- Just TInt
--
-- >>> tbinary Add TInt TBool
-- Nothing
tunary :: UnaryOp -> Type -> Maybe Type
tunary = error "TODO: Question 4"

tbinary :: BinaryOp -> Type -> Type -> Maybe Type
tbinary = error "TODO: Question 4"


-- | Question 5
--
-- >>> testq4 "1"
-- Just TInt
--
-- >>> testq4 "false"
-- Just TBool
--
-- >>> testq4 "1*false"
-- Nothing
--
-- >>> testq4 "var x = 5; if (x > 0) x; else x * x"
-- Just TInt
--
-- >>> testq4 "var x = y; var y = 3; x + y"
-- Nothing
tcheck :: Exp -> TEnv -> Maybe Type
tcheck = error "TODO: Question 4"

-- | Question 6
--
-- >>> tcalc "3 == 3"
-- true
--
-- >>> tcalc "if (3 == 4) true; else false"
-- false
--
-- >>> tcalc "var x = 3; x + true"
-- *** Exception: You have a type-error in your program!
tcalc :: String -> Value
tcalc = error "TODO: Question 5"




testq4 :: String -> Maybe Type
testq4 e = tcheck (parseExpr e) []
