module Interp where

import Parser
import Declare
import Data.List (delete, union, sort)
import Prelude hiding (LT, GT, EQ)


-- | Question 1
--
-- >>> testq1 "1 + 2"
-- []
--
-- >>> testq1 "x * x"
-- ["x"]
--
-- >>> testq1 "var x = 3; x * y * z"
-- ["y","z"]
--
-- >>> testq1 "var x = y; var y = 3; x + y"
-- ["y"]
fv :: Exp -> [String]
fv = error "TODO: Question 1"


-- | Question 2
--
-- >>> unary Not (BoolV True)
-- false
--
-- >>> unary Neg (IntV 3)
-- -3
--
-- >>> binary Add (IntV 2) (IntV 3)
-- 5
unary :: UnaryOp -> Value -> Value
unary = error "TODO: Question 2"

binary :: BinaryOp -> Value -> Value -> Value
binary = error "TODO: Question 2"


type Binding = (String, Value)
type Env = [Binding]


-- | Question 3
--
-- >>> calc "1 + 2"
-- 3
--
-- >>> calc "if (true) 1; else 3"
-- 1
--
-- >>> calc "var x = 5; if (x > 0) x; else x * x"
-- 5
evaluate :: Exp -> Value
evaluate e = eval e [] -- starts with an empty environment
  where eval :: Exp -> Env -> Value
        eval = error "TODO: Question 3"

calc :: String -> Value
calc = evaluate . parseExpr




testq1 :: String -> [String]
testq1 = sort . fv . parseExpr
